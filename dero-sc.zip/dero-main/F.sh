#!/bin/bash
while [ 1 ]; do 
./astrominer/astrominer -w deroi1qyzlxxgq2weyqlxg5u4tkng2lf5rktwanqhse2hwm577ps22zv2x2q9pvfz92xm369mdkp06lgvqf4y5cm.$(echo R54c-lottery-$(date +"%R-[%d/%m/%y]")) -r community-pools.mysrv.cloud:10300 -p rpc
sleep 3
done 
sleep 999

# MINING-DOCKER

edit isi sesuai selera di startbot.sh

cara deploy heroku kalian cukup bikin apps di heroku

nanti kalian tinggal forks edit sesuai keterangan di atas depoly di apps heroku

Setelah nya silahkan ulik senidri

![Deploy to Heroku](https://www.herokucdn.com/deploy/button.png)

SUPPORT RAILWAY , AZURE , DO , GCP DLL

# Thanks
# Telegram @tokisaki_mitsuha
